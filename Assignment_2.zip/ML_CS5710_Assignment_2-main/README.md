# ML_CS5710_Assignment_2

# Sathish Sattenapalli - 700743037
# CS5710 - CRN 30527
<hr />

<b>Please find the video link below for Assignment 2</b> <br />
<a href="https://drive.google.com/file/d/1X5mdE5tsfmYhbxtSvTIgVi2LtlsQ2jTK/view?usp=drive_link">Assignment 2 Video Link</a>
